package edu.polytech.ihmtd2dechet;

public class ApplicationEvenement {
    public static String VALUE_TITRE = "valeur titre";
    public static String VALUE_DESCRIPTION = "valeur description";
    public static String VALUE_DATE = "valeur date";
    public static String VALUE_LIEU = "valeur lieu";
    public static int VALUE_IMAGE;

    public ApplicationEvenement(){
        
    }


}
