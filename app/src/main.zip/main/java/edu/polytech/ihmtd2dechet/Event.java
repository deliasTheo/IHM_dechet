package edu.polytech.ihmtd2dechet;

public class Event {
}
