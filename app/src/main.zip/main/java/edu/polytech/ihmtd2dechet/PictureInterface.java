package edu.polytech.ihmtd2dechet;

public interface PictureInterface {
    int REQUEST_CAMERA = 100;
}
